<?php

declare(strict_types=1);

namespace KodLion;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase {

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if($command->getName() === "fly"){
            if(!$sender instanceof Player){
                $sender->sendMessage("§cBu komut sadece oyunda kullanılabilir!");
                return true;
            }

            if($sender->getAllowFlight()){
                $sender->setAllowFlight(false);
                $sender->setFlying(false);
                $sender->sendMessage("§c» Uçma modu kapatıldı!");
            } else {
                $sender->setAllowFlight(true);
                $sender->sendMessage("§a» Uçma modu açıldı!");
            }
            return true;
        }
        return false;
    }
}